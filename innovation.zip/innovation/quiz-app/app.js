const express = require("express");
const app = express();
const path = require("path");
const questions = require("./data/questions.json");

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.render("index");
});

app.get("/quiz", (req, res) => {
  res.render("quiz", { questions });
});

app.post("/result", (req, res) => {
  const score = parseInt(req.body.score) || 0;
  res.render("result", { score, total: questions.length });
});

app.listen(3000, () => {
  console.log("Server is running on http://localhost:3000");
});
